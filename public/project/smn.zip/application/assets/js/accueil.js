
$(document).ready(function() {
  var btnRediffusion=$('.btnRediffusion')
  var btnProgram=$('.pro')
  var btnPoster=$('.btnPoster')
  var backgrounDiv=$('.background')
  var header=$('.header')
  
  // jsContent 
});